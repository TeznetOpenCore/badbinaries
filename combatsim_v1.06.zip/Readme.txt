A1.COMBAT.SIM is a C++ Binary Executable assembled with ELF, you will require:

Linux Operating System

Bash (make the launcher executable)

Gnome, hterm, or xfce4 terminal to run the game

./launcher -should launch the game if they are both extracted to the same local directory
