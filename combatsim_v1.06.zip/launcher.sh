#!/usr/bin/env bash

set -e

# Change to the directory containing this script
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

GAME="./combatsim_v1.06"

if [ ! -x "$GAME" ]; then
    echo "Error: $GAME not found or not executable."
    exit 1
fi

# Prevent launching multiple copies
if pgrep -f "$GAME" >/dev/null; then
    echo "CombatSim is already running."
    exit 0
fi

# Launch fullscreen terminal
if command -v gnome-terminal >/dev/null 2>&1; then
    exec gnome-terminal --full-screen -- "$GAME"

elif command -v konsole >/dev/null 2>&1; then
    exec konsole --fullscreen -e "$GAME"

elif command -v xfce4-terminal >/dev/null 2>&1; then
    exec xfce4-terminal --fullscreen -x "$GAME"

elif command -v xterm >/dev/null 2>&1; then
    exec xterm -fullscreen -e "$GAME"

else
    echo "No supported terminal emulator found."
    echo "Install gnome-terminal, konsole, xfce4-terminal, or xterm."
    exit 1
fi
